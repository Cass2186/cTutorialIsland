package scripts.GEManager;


import dax.walker_engine.interaction_handling.NPCInteraction;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.*;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.*;
import org.tribot.script.sdk.Log;
import org.tribot.script.sdk.Waiting;
import scripts.*;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

public class Exchange {

    public static int GE_PARENT = 465;
    public static int CONFIRM_OFFER_ID = 54;
    public static int SEARCH_ITEM_NAME_INTERFACE_ID = 42;
    public static int GE_BOOTH_ID = 10061;


    public static String GE_CLERK_STRING = "Grand Exchange Clerk";

    public static RSInterface[] interfaceChildren;
    public static int componentItem;

    public static RSInterface BUY_1 = Interfaces.get(465, 7, 3);
    public static RSInterface ADD_5_PERCENT_BUTTON = Interfaces.get(465, 24, 13);


    public static ArrayList<Integer> price = new ArrayList<Integer>();


    public static RSArea GE_Area = new RSArea(new RSTile(3160, 3494, 0), new RSTile(3168, 3485, 0));


    /***********
     * METHODS *
     ***********/


    public static boolean goToSelectionWindow() {
        return GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.SELECTION_WINDOW ||
                GrandExchange.goToSelectionWindow(true);
    }

    public static RSGEOffer getEmptyOffer() {
        if (goToSelectionWindow()) {
            RSGEOffer[] offers = GrandExchange.getOffers();
            for (RSGEOffer ofr : offers) {
                if (ofr.getStatus() == RSGEOffer.STATUS.EMPTY)
                    return ofr;
            }
        }
        return null;
    }


    public static boolean checkIfItemIsInHashMap(int item, HashMap<Integer, Integer> map) {
        for (Integer i : map.keySet()) {
            if (i == item)
                return true;
        }
        return false;
    }

    public static int getListPrice(RSGEOffer offer) {
        int index = offer.getIndex() + 7;
        int price = offer.getPrice();
        General.println("[Exchanger]: (getRelistPrice()) price of offer item is " + price);
        if (Interfaces.isInterfaceSubstantiated(465, index, 25)) {
            try {
                String offerPrice = Interfaces.get(465, index, 25).getText().replace(" coins", "");
                offerPrice = offerPrice.replace(",", "");
                price = Integer.parseInt(offerPrice);
                General.println("[Exchanger]: Price for the current offer is " + price + " coins");
                return price;
            } catch (Exception e) {
                General.println("[Exchanger]: Failed to get relist price");
                e.printStackTrace();
            }

        }
        return price;
    }

    public static boolean closeGE() {
        return GrandExchange.close(true);
    }

    public static boolean isGrandExchangeOpen() {
        return (GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.SELECTION_WINDOW ||
                GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.OFFER_WINDOW ||
                GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.NEW_OFFER_WINDOW);

    }

    /**
     * will move to GE, get coins, close bank and attempt to open GE
     *
     * @return if GE was opened successfully
     */
    public static boolean openGE() {
        if (!GE_Area.contains(Player.getPosition()))
            PathingUtil.walkToArea(GE_Area, false);

        if (Inventory.find(995).length < 1) {
            //get Coins
        }

        if (Banking.isBankScreenOpen())
            Banking.close(); //replace with custom method later

        RSObject[] booth = Objects.findNearest(20, Filters.Objects.actionsContains("Exchange"));

        if (!isGrandExchangeOpen() && booth.length > 0) {
            if (Utils.clickObject(booth[0], "Exchange", true))
                Timer.waitCondition(() -> GrandExchange.getWindowState() ==
                        GrandExchange.WINDOW_STATE.SELECTION_WINDOW ||
                        NPCInteraction.isConversationWindowUp(), 5000, 7000);

            if (NPCInteraction.isConversationWindowUp()) {
                NPCInteraction.handleConversation("I'd like to set up trade offers please.");
                return Timer.waitCondition(() -> (GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.SELECTION_WINDOW), 5000, 7000);
            }
        }

        return GrandExchange.getWindowState() ==
                GrandExchange.WINDOW_STATE.SELECTION_WINDOW;
    }


    /**
     * will open a buy offer window
     *
     * @return if successful or not
     */
    public static boolean startBuyOffer() {
        if (!isGrandExchangeOpen())
            openGE();
        //  checkIfWeNeedToCollect();
        // this allows it to loop if it has to collect first
        for (int i = 0; i < 2; i++) {
            RSGEOffer ofr = getEmptyOffer();
            if (ofr != null) {
                int index = ofr.getIndex();
                General.println("[GEManager]: Creating buy offer: " + index);
                String s = "Create <col=ff9040>Buy</col> offer";
                if (InterfaceUtil.click(465, index + 7, 3))
                    return Timer.waitCondition(() ->
                            Interfaces.isInterfaceSubstantiated(162, SEARCH_ITEM_NAME_INTERFACE_ID), 7000, 9000);

            } else {
                clickCollect();
            }
        }
        return false;
    }

    private static String determineShortName(String fullName) {
        int stringLength = fullName.length();
        try {
            if (stringLength > 11) {
                int firstInt = General.random(6, 10);
                int secondInt = firstInt + 1;
                char firstChar = fullName.charAt(firstInt);
                String splitHere = firstChar + Character.toString(fullName.charAt(secondInt));
                return fullName.split(splitHere)[0];

            }
        } catch (Exception e) {
            return fullName;
        }
        return fullName;
    }

    private static String getItemName(GEItem item) {
        RSItemDefinition itemDef = RSItemDefinition.get(item.getItemId());
        String itemString = itemDef.getName();

        if (itemString != null && itemString.length() > 10) {
            itemString = determineShortName(itemString);
            General.println("[GEManager]: Truncated item string: " + itemString);
        }

        if (itemString != null && itemString.contains("("))
            itemString = itemString.split("\\(")[0];

        return itemString;
    }

    public static boolean selectBuyItem(GEItem item) {
        // should  check there's a valid item to buy before all this

        startBuyOffer();
        String itemString = getItemName(item);

        if (Interfaces.isInterfaceSubstantiated(162, 50)) {
            Keyboard.typeString(itemString.toLowerCase());
            Waiting.waitUniform(1000,2000);

            if (Interfaces.isInterfaceSubstantiated(Interfaces.get(162, 50))) {
                // this allows it to load items, otherwise it'll skip it
                Timer.slowWaitCondition(() -> Interfaces.get(162, 50).getChildren() != null, 5000, 6000);

                interfaceChildren = Interfaces.get(162, 50).getChildren();
                if (interfaceChildren != null) {
                    General.println("Line 381 - length = " + interfaceChildren.length);

                    for (int i = 0; i < interfaceChildren.length; i++) {
                        componentItem = Interfaces.get(162, 50, i).getComponentItem();
                        General.println("Line 385 - ID: " + componentItem + " || Item We are looking for " +
                                item.getItemId());

                        if (componentItem == item.getItemId()) {

                            if (i > 24) {// item should be off screen if this is true
                                Interfaces.get(162, 50, i).getY();

                                if (!Interfaces.get(162, 50).getAbsoluteBounds().contains(Mouse.getPos())) {
                                    Mouse.moveBox(Interfaces.get(162, 50).getAbsoluteBounds());

                                    if ((Interfaces.get(162, 50, i).getY() > 65)) { // is off screen if this is true

                                        long startTime = System.currentTimeMillis();
                                        long add = General.random(7000, 15000);

                                        while (Interfaces.get(162, 50, i).getAbsolutePosition().getY() >
                                                (Interfaces.get(162, 51, 3).getAbsolutePosition().getY())) {

                                            // trying these next two lines here
                                            if (!Interfaces.get(162, 50).getAbsoluteBounds().contains(Mouse.getPos()))
                                                Mouse.moveBox(Interfaces.get(162, 50).getAbsoluteBounds());

                                            Mouse.scroll(false); //scrolls down
                                            General.sleep(General.random(150, 500));

                                            if (System.currentTimeMillis() > startTime + add)
                                                break;
                                        }
                                    }

                                    General.sleep(400, 600);

                                    if (Interfaces.get(162, 50, i).click())
                                        return Timer.waitCondition(() -> Interfaces.get(465, 24, 21) != null &&
                                                Interfaces.get(465, 24, 21).getComponentItem() ==
                                                        item.getItemId(), 4000, 6000);

                                } else if (Interfaces.get(162, 50, i).click())
                                    return Timer.waitCondition(() -> Interfaces.get(465, 24, 21) != null &&
                                            Interfaces.get(465, 24, 21).getComponentItem() ==
                                                    item.getItemId(), 4000, 6000);


                            } else if (Interfaces.get(162, 50, i).click())
                                return Timer.waitCondition(() -> Interfaces.get(465, 24, 21) != null &&
                                        Interfaces.get(465, 24, 21).getComponentItem() == item.getItemId(), 4000, 6000);

                        }
                    }
                }
            }
        }

        return false;
    }


    private static boolean pressFivePercentIncrease(double percentIncrease) {
        if (percentIncrease == 5 || percentIncrease == 10 || percentIncrease == 15 || percentIncrease == 20 || percentIncrease == 25 || percentIncrease == 30
                || percentIncrease == 35 || percentIncrease == 40 || percentIncrease == 45 || percentIncrease == 50) { // we are better off typing if we need to press more than 4 times.
            if (Interfaces.isInterfaceSubstantiated(465, 24, 13)) {
                for (int i = 0; i < (percentIncrease / 5); i++) {
                    if (Interfaces.get(465, 24, 13).click())
                        General.sleep(General.randomSD(50, 400, 200, 75));
                }
                return true;
            }
        }
        return false;
    }

    private static boolean pressFivePercentDecrease() {
        if (Interfaces.isInterfaceSubstantiated(465, 24, 10))
            return Interfaces.get(465, 24, 10).click();

        return false;
    }

    public static void buyItem(GEItem geItem) {

        if (geItem.getItemQuantity() == 0)
            return;

        if (Inventory.find(995).length < 1) {
            BankManager.open(true);
            BankManager.withdraw(0, true, 995);
            BankManager.withdrawArray(ItemId.RING_OF_WEALTH, 1);
        }

        if (Banking.isBankScreenOpen())
            Banking.close(); //replace with a custom method


        RSItemDefinition itemDef = RSItemDefinition.get(geItem.itemId);
        String itemString = itemDef.getName(); //needs null check or optional

        for (int i = 0; i < 3; i++) {
            openGE();
            if (Interfaces.isInterfaceSubstantiated(GE_PARENT))
                break;
        }
        if (getEmptyOffer() == null) {
            collectItems();
        }
        General.println("[GEManager]: Buying: " + itemString + " x " + geItem.quantity + " for " + geItem.percentIncrease + "% more");
        if (selectBuyItem(geItem))
            General.sleep(General.random(800, 1500)); // lets load

        if (Interfaces.isInterfaceSubstantiated(GE_PARENT)
                && Interfaces.get(GE_PARENT, 24, 21).getComponentItem() == geItem.itemId) {

            if (geItem.quantity != 1 && Interfaces.get(GE_PARENT, 24, 7) != null) { // selects item amount (custom)
                if (Interfaces.get(GE_PARENT, 24, 7).click()) {
                    Timer.waitCondition(() -> !Interfaces.get(162, 41).isHidden(), 4000, 6000);

                    if (!Interfaces.get(162, 41).isHidden() && itemString != null) {
                        Keyboard.typeString(String.valueOf(geItem.quantity));
                        Keyboard.pressEnter();
                        Timer.waitCondition(() -> Interfaces.isInterfaceSubstantiated(Interfaces.get(465, 24, 39)), 9000, 12000);
                        General.sleep(General.random(600, 1400)); //was before waitCondition
                    }
                }
            }
            if (Interfaces.isInterfaceSubstantiated(GE_PARENT, 24, 39)) { // selects item price (custom)
                int grandExchangePrice = GrandExchange.getGuidePrice();
                double db = geItem.percentIncrease / 100;
                General.println("[Debug]: Percent to add " + geItem.percentIncrease);
                General.println("[Debug]: Percent of current price " + (geItem.percentIncrease / 100 + 1));
                double offerPrice = Math.round(grandExchangePrice * (geItem.percentIncrease / 100 + 1));
                int realOfferPrice = (int) (5 * (Math.round(offerPrice / 5)) + 5);

                if (realOfferPrice > 2000)
                    realOfferPrice = (int) (100 * (Math.round(offerPrice / 100)));

                General.println("[GEManager]: GE List Price: " + grandExchangePrice);
                General.println("[GEManager]: Offer Price: " + realOfferPrice);

                //types price
                if (!pressFivePercentIncrease(geItem.percentIncrease)) {
                    if (Interfaces.get(465, 24, 12) != null) {
                        if (Interfaces.get(465, 24, 12).click())
                            Timer.waitCondition(() ->
                                            Interfaces.isInterfaceSubstantiated(162, 41),
                                    5000, 8000); // waits for price typing chat box

                        General.sleep(300, 600);// time for moving your hand from the mouse to keyboard

                        if (Interfaces.get(162, 41).isHidden() && //failsafe
                                Interfaces.get(465, 24, 12).click()) // click custom price
                            Timer.waitCondition(() ->
                                    !Interfaces.isInterfaceSubstantiated(162, 41), 5000, 8000); // waits for price typing chat box

                        if (Interfaces.isInterfaceSubstantiated(162, 41)) {
                            Keyboard.typeString(String.valueOf(realOfferPrice));

                            if (!Interfaces.get(162, 41).isHidden()) { // confirms we've typed it in the right area, so we don't click enter on chatbox
                                Keyboard.pressEnter();
                                General.sleep(200, 500);
                            }
                        }
                    }
                }
            }
            if (Interfaces.get(GE_PARENT, 24, CONFIRM_OFFER_ID).click()) { // clicks confirm offer
                General.sleep(General.randomSD(800, 5000, 2000, 500)); //need this sleep after clicking confirm

            } else { // if the itemId in the image is not the right one (i.e. we selected the wrong item)
                if (Interfaces.isInterfaceSubstantiated(GE_PARENT, 4)) {
                    General.println("[GEManager]: Misclicked item... going back to offer screen.");
                    GrandExchange.goToSelectionWindow(true);
                    General.sleep(800, 2000);
                }
            }
        }
    }

    public static boolean shouldCollect;
    public static int INCOMPLETED_OFFER;
    public static int COMPLETED_OFFER;
    public static boolean SHOULD_WAIT = true;


    public static void collectItems() {
        // waitForOfferToCompleteAndRelist();
        boolean shouldWait = true;
        long currentTime = System.currentTimeMillis();

        while (shouldWait) {
            General.sleep(50);
            INCOMPLETED_OFFER = 0;
            COMPLETED_OFFER = 0;
            SHOULD_WAIT = false; // while the bottom 4 conditions should cover everything, this ensures it doesn't loop indefinitely should another situation occur
            RSGEOffer[] offers = GrandExchange.getOffers();
            for (RSGEOffer of : offers){
                if(of.getStatus().equals(RSGEOffer.STATUS.EMPTY))
                    continue;
                else if (of.getStatus().equals(RSGEOffer.STATUS.IN_PROGRESS)){
                    Log.log("[Exchange]: at least one offer is in progess, waiting");
                    Waiting.waitUniform(1500,5000);
                    checkRelist();
                }
            }
            for (int i = 7; i < 14; i++) {
                if (Interfaces.get(465, i, 22) != null) {
                    if (Interfaces.get(465, i, 22).getTextColour() == 14188576) { // this is blank bar
                        INCOMPLETED_OFFER++;
                    } else if (Interfaces.get(465, i, 22).getTextColour() == 24320) { //  this is the green bar
                        COMPLETED_OFFER++;
                    }
                }
            }


            if (COMPLETED_OFFER > 0 && INCOMPLETED_OFFER > 0) {
                General.println("[Debug]: >= 1 completed offer and incompleted offer, collecting and waiting");
                int b = General.randomSD(3500, 400);
                Log.log("[Debug]: Sleeping for  " + b + "ms");
                Waiting.wait(b);
                clickCollect();
                SHOULD_WAIT = true; // will cause loop to continue
                General.sleep(800, 1500); // short sleep to wait for offers (decrease CPU Use)
            } else if (COMPLETED_OFFER == 0 && INCOMPLETED_OFFER > 0) {
                General.println("[Debug]: < 1 completed offer and >0 incompleted offers, waiting");
                SHOULD_WAIT = true; // will cause loop to continue
                checkRelist();
                General.sleep(800, 1500); // short sleep to wait for offers (decrease CPU Use)
            } else if (COMPLETED_OFFER > 0 && INCOMPLETED_OFFER == 0) {
                General.println("[Debug]: >= 1 completed offer and NO incompleted offers, collecting");
                Utils.abc2ReactionSleep(currentTime);
                clickCollect();
                SHOULD_WAIT = false; // by declaring SHOULD_WAIT false here, it ensures we break the loop, otherwise it would continue
                break;
            } else if (COMPLETED_OFFER == 0 && INCOMPLETED_OFFER == 0) { // no offers placed, will break the loop
                General.println("[Debug]: No offers placed.");
                SHOULD_WAIT = false;
                break;
            }

        }
    }

    public static RSGEOffer IN_PROGRESS_OFFER;

    /**
     * used to check if we have any placed offers that HAVE NOT completed
     *
     * @returns as true if there's >=1 in progress offer
     */
    private static Optional<RSGEOffer> checkForOffersInProgress() {
        if (GrandExchange.getWindowState() != GrandExchange.WINDOW_STATE.SELECTION_WINDOW)
            openGE();

        if (goToSelectionWindow()) {
            RSGEOffer[] offers = GrandExchange.getOffers();
            for (RSGEOffer ofr : offers) {
                if (ofr.getStatus() == RSGEOffer.STATUS.IN_PROGRESS &&
                        ofr.getType() == RSGEOffer.TYPE.BUY) {
                    return Optional.of(ofr);

                }
            }
        }
        return Optional.empty();
    }

    public static void checkRelist() {
        if (GrandExchange.getWindowState() == GrandExchange.WINDOW_STATE.SELECTION_WINDOW) {
            clickCollect(); // collects items first, otherwise an issue if all windows are in use
            General.sleep(General.random(1500, 3000)); // allows for the last offer placed to insta-complete if it's going to.

            Optional<RSGEOffer> offer = checkForOffersInProgress();
            if (offer.isPresent()) {
                int index = offer.get().getIndex() + 7; // 7 is to make index be the right child
                int amount = 1;

                if (Interfaces.isInterfaceSubstantiated(465, index, 18))
                    amount = Interfaces.get(465, index, 18).getComponentStack();

                int id = offer.get().getItemID();
                int price = offer.get().getPrice();

                price = getListPrice(offer.get());

                General.println("[GEManager]: Relisting item: " + RSItemDefinition.get(id).getName() + " at " + (price * 1.2) + " coins");

                if (offer.get().click("Abort offer")) {
                    General.println("[GEManager]: Aborting offer");
                    Timer.waitCondition(() -> offer.get().getStatus() == RSGEOffer.STATUS.CANCELLED, 6000, 8000);
                }
                int newPrice = (int) (price * 1.2) + 10;
                // will attempt to re-buy at 20% more, does not collect canceled gold before.
                buyItemFlat(id, newPrice, amount);

            }

        }
    }

    public static void buyItemFlat(int itemID, int flatPrice, int quantity) {
        BankManager.determinePurchaseAmounts(itemID, quantity);
        RSItemDefinition itemDef = RSItemDefinition.get(itemID);
        String itemString = itemDef.getName();
        if (BankManager.itemsToBuy < 0) {
            // DO NOT try and close the GE Here, it will close and open it for each item if you do this
            return;
        }
        if (BankManager.itemsToBuy > 0) {
            General.println("[GEManager]: Buying: " + itemString + " x " + BankManager.itemsToBuy);
            selectBuyItem(new GEItem(itemID, quantity));
            General.sleep(General.random(300, 2000));
            if (Interfaces.get(465) != null) { // Main GE Interface
                if (Interfaces.get(465, 24, 21).getComponentItem() == itemID) { // confirms we've selected the right item.
                    if (BankManager.itemsToBuy > 1) {
                        if (Interfaces.get(465, 24, 7) != null) { // selects item amount (custom)
                            Interfaces.get(465, 24, 7).click();
                            Timing.waitCondition(() -> !Interfaces.get(162, 44).isHidden(), General.random(4000, 6000));
                            Waiting.waitUniform(500, 1000);
                            Keyboard.typeString(String.valueOf(BankManager.itemsToBuy));
                            Keyboard.pressEnter();
                            General.sleep(800, 1300);
                        }
                    }
                    Timing.waitCondition(() -> Interfaces.isInterfaceSubstantiated(Interfaces.get(465, 24, 39)), 10000);
                    if (Interfaces.get(465, 24, 39) != null) { // selects item price (custom)
                        String[] split2 = Interfaces.get(465, 24, 39).getText().split(" coin");
                        String split = split2[0].replaceAll(",", "");
                        if (split.length() > 0) {
                            int GEPRICE = Integer.parseInt(split);
                            General.println("[GEManager]: GE Price: " + GEPRICE);
                            General.println("[GEManager]: Using Flat Price: " + flatPrice);
                            RSInterface listPriceButton = Interfaces.get(465, 24, 12);
                            if (listPriceButton != null &&
                                    listPriceButton.click()) {
                                Timer.waitCondition(() -> Interfaces.isInterfaceSubstantiated(162, 41), General.random(5000, 8000));
                                Log.log("[Debug]: Timer ended");
                                Keyboard.typeString(String.valueOf(flatPrice));
                                General.sleep(100, 400);
                                if (Interfaces.isInterfaceSubstantiated(162, 41)) { // confirms we've typed it in the right area, so we don't click enter on chatbox
                                    Keyboard.pressEnter();
                                }
                                General.sleep(1200, 3000); // this would be the time from typing to grabbing your mouse
                                if (Interfaces.get(465, 24, 54).click())
                                    Waiting.waitNormal(1500, 300);
                            }
                        }
                    }
                } else { // if the itemId in the image is not the right one (i.e. we selected the wrong item)
                    if (Interfaces.get(465, 4) != null) {
                        General.println("[GEManager]: Misclicked item... going back to offer screen.");
                        Interfaces.get(465, 4).click();
                        General.sleep(General.random(800, 2000));
                    }
                }
            }
        } else {
            return;

        }
    }

    public static boolean clickCollect() {
        if (Interfaces.isInterfaceSubstantiated(465, 6, 1)) {
            General.println("[GEManager]: Collecting");
            if (!Interfaces.get(465, 6, 1).isHidden()) { // this is the collect button, it's never null, so we check if it's hidden
                Interfaces.get(465, 6, 1).click();
                General.sleep(General.random(300, 1000));
                Timing.waitCondition(() -> BankManager.inventoryChange(true), General.random(3000, 5000));
                if (Interfaces.isInterfaceSubstantiated(465, 6, 1)) {
                    General.println("[Debug]: Still have a valid collect bar, trying to collect again.");
                    return Interfaces.get(465, 6, 1).click();

                } else {
                    return true;
                }
            }
        }
        return false;
    }


}
