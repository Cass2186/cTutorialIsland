package scripts.Requirements;

public interface Requirement {

    boolean check();
}
