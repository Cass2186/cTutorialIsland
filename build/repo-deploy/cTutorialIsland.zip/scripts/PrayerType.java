package scripts;

public enum PrayerType {

    NONE,
    MAGIC,
    MISSLES,
    MELEE;
}
