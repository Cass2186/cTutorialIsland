package scripts;

public class GameSettings {

    public static int HAZEEL_CULT = 223;
}
