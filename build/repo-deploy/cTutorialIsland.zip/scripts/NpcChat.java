package scripts;

import dax.walker.utils.AccurateMouse;
import dax.walker.utils.camera.DaxCamera;
import dax.walker_engine.interaction_handling.NPCInteraction;
import org.tribot.api2007.NPCChat;
import org.tribot.api2007.NPCs;
import org.tribot.api2007.Player;
import org.tribot.api2007.types.RSNPC;


public class NpcChat extends NPCChat {


    public static boolean talkToNPC(String npcName) {
        RSNPC[] targetNPC = NPCs.findNearest(npcName);
        if (targetNPC.length > 0) {
            if (!targetNPC[0].isOnScreen()) {
                if (targetNPC[0].getPosition().distanceTo(Player.getPosition()) <= 5) {
                    DaxCamera.focus(targetNPC[0]);
                } else if (!PathingUtil.localNavigation(targetNPC[0].getPosition())) {
                    if (PathingUtil.walkToTile(targetNPC[0].getPosition(), 2, false))
                        Timer.waitCondition(() -> targetNPC[0].isClickable(), 8000);
                }
            }
            for (int i = 0; i < 3; i++) {
                if (AccurateMouse.click(targetNPC[0], "Talk-to"))
                    return true;

            }
        }
        return false;
    }

    public static boolean talkToNPC(RSNPC npc) {
        if (npc != null) {
            if (!npc.isOnScreen()) {
                if (npc.getPosition().distanceTo(Player.getPosition()) <= 5) {
                    DaxCamera.focus(npc);
                } else if (PathingUtil.localNavigation(npc.getPosition())) {
                    PathingUtil.movementIdle();
                } else if (PathingUtil.walkToTile(npc.getPosition(), 2, false)) {
                    Timer.waitCondition(() -> npc.isClickable(), 8000);
                }
            }
            for (int i = 0; i < 3; i++) {
                if (AccurateMouse.click(npc, "Talk-to"))
                    return true;

            }
        }
        return false;
    }


    public static boolean talkToNPC(RSNPC npc,  String interactionString) {
        if (npc != null) {
            if (!npc.isOnScreen()) {
                if (npc.getPosition().distanceTo(Player.getPosition()) <= 5) {
                    DaxCamera.focus(npc);
                } else if (PathingUtil.localNavigation(npc.getPosition())) {
                    PathingUtil.movementIdle();
                } else if (PathingUtil.walkToTile(npc.getPosition(), 2, false)) {
                    Timer.waitCondition(() -> npc.isClickable(), 8000);
                }
            }
            for (int i = 0; i < 3; i++) {
                if (AccurateMouse.click(npc, interactionString))
                    return true;

            }
        }
        return false;
    }

    public static boolean talkToNPC(int npcName) {
        RSNPC[] targetNPC = NPCs.findNearest(npcName);
        if (targetNPC.length > 0) {
            if (!targetNPC[0].isOnScreen()) {
                if (targetNPC[0].getPosition().distanceTo(Player.getPosition()) <= 5) {
                    DaxCamera.focus(targetNPC[0]);
                } else if (!PathingUtil.localNavigation(targetNPC[0].getPosition())) {
                    if (PathingUtil.walkToTile(targetNPC[0].getPosition(), 2, false))
                        Timer.waitCondition(() -> targetNPC[0].isClickable(), 8000);
                }
            }
            for (int i = 0; i < 3; i++) {
                if (AccurateMouse.click(targetNPC[0], "Talk-to"))
                    return true;
            }
        }
        return false;
    }

    public static boolean talkToNPC(int npcName, String interactionString) {
        RSNPC[] targetNPC = NPCs.findNearest(npcName);
        if (targetNPC.length > 0) {
            if (!targetNPC[0].isOnScreen()) {
                if (targetNPC[0].getPosition().distanceTo(Player.getPosition()) <= 5) {
                    DaxCamera.focus(targetNPC[0]);
                } else if (!PathingUtil.localNavigation(targetNPC[0].getPosition())) {
                    if (PathingUtil.walkToTile(targetNPC[0].getPosition(), 2, false))
                        Timer.waitCondition(() -> targetNPC[0].isClickable(), 8000);
                }
            }
            for (int i = 0; i < 3; i++) {
                if (AccurateMouse.click(targetNPC[0], interactionString))
                    return true;
            }
        }
        return false;
    }
}
