package scripts.QuestSteps;

import lombok.Getter;
import scripts.Requirements.ItemReq;
import scripts.Requirements.Requirement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DetailedQuestStep {

    @Getter
    protected final List<Requirement> requirements = new ArrayList<>();


    public void addRequirement(Requirement requirement)
    {
        requirements.add(requirement);
    }

    public void addRequirement(Requirement... requirements)
    {
        this.requirements.addAll(Arrays.asList(requirements));
    }

    public void addItemRequirements(List<ItemReq> requirement)
    {
        requirements.addAll(requirement);
    }

    public void emptyRequirements()
    {
        requirements.clear();
    }

    public void setRequirements(List<Requirement> newRequirements)
    {
        requirements.clear();
        requirements.addAll(newRequirements);
    }

}
