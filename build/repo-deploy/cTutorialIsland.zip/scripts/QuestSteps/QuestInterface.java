package scripts.QuestSteps;

public interface QuestInterface {

    public String questName();
    
    //public int gameSetting();
}
