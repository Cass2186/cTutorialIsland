package scripts.Tasks;

/**
 * Credit to @Encoded for the Framework
 */
public enum Priority {
    HIGHEST,
    HIGH,
    MEDIUM,
    LOW,
    LOWEST,
    NONE

}